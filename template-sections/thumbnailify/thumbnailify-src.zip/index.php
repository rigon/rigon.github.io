<?php
$proto = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') ? "https" : "http";
$address=$proto."://".$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'];
//$base_address=$proto."://".$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF']);

$image = isset($_GET['f']) ? $_GET['f'] : /*$base_address."*/ "Siberian-Tiger.jpg";

if(!isset($_GET['test']) && isset($_GET['f'])) {
    // New dimensions for the resized image
    $new_width = 96; // Set your desired width
    $new_height = 72; // Set your desired height

    // Load the original image
    $original_image = imagecreatefromjpeg($image);

    // Get the original dimensions
    $original_width = imagesx($original_image);
    $original_height = imagesy($original_image);

    // Create a new image with the desired dimensions
    $resized_image = imagecreatetruecolor($new_width, $new_height);

    // Resize the original image to the new dimensions
    imagecopyresized($resized_image, $original_image, 0, 0, 0, 0, $new_width, $new_height, $original_width, $original_height);

    // Set the content type header to JPEG
    header('Content-Type: image/jpeg');

    // Output the resized image directly to the browser
    imagejpeg($resized_image, null);

    // Free up memory by destroying the image resources
    imagedestroy($original_image);
    imagedestroy($resized_image);

    exit;
}

$urlimage=urlencode($image);

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" 
   "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html>
	<head>
		<title>Thumbnailify</title>
	
		<style type="text/css">
			html {
				background-color: #333;
			}
			body {
				background-color: white;
				color: #4b4742;

				line-height: 20px;
				font-family: georgia;
				border: 1px solid black;
				margin: 20px auto 20px auto;
				padding: 20px 50px 20px 50px;
				max-width: 80%;
				min-height: 750px;
				
				-moz-box-shadow: 0px 0px 60px black;
				-webkit-box-shadow: 0px 0px 60px black;
				/* box-shadow: 0px 0px 60px black; */
				
				-webkit-border-radius: 10px;
				-moz-border-radius: 10px;
				text-align: justify;
			}

			a {
				color: #4b4772;
				text-decoration: inherit;
			}

			a:HOVER, a:FOCUS {
				color: #9b97a2;
				text-decoration: overline;
			}
			
			code {
				display: block;
				border: 1px dotted #bcdeff;
				padding: 5px 5px 5px 5px;
				background-color: #f4ffff;
				margin: 10px 0px 10px 0px;
				overflow: auto;
				width: 100%;
				white-space: nowrap;
			}
			
			h1 {
				vertical-align: middle;
				font-size: 40px;
				text-shadow: 1px 1px 1px lightgray;
			}
			p {
				margin: 0px 0px 5px 0px;
			}
		</style>
	</head>
	<body>
		<h1>Thumbnailify images for your site</h1>
		<p>This application creates automatically thumbnails of images. It's ideal to generate the thumbnails of a photo gallery.</p>
		<p>To use in your site, you need use this address:</p>
		<code>
			<?php echo $address; ?>?f=</i><b>&lt;address to the image&gt;</b></p>
		</code>

		<p>Insert the address to thumbnailify your image:</p>
		<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="get" name="font">
			<p>
				<input name="f" type="text" value="<?php echo urldecode($image) ?>" style="width: 400px" />
				<input type="submit" value="Test Image" name="test" />
				<input type="submit" value="Get Thumbnail" name="get" />
				<input type="button" value="Download Image" onclick="javascript: window.location=font.f.value;" />
			</p>
		</form>
		
		<p>For this image, you should use the next address to get the thumbnail:</p>
		<code>
			<?php echo "$address?f=$urlimage"; ?>
		</code>
		<br />
		<table width="100%" style="max-width:100%;">
			<tr>
				<th align="center">Original</th>
				<th align="center">Thumbnail</th>
			<tr>
			<tr>
				<td align="center">
					<img src="<?php echo $image; ?>" alt="Original" style="max-width:1000px;">
				</td>
				<td align="center">
					<img src="<?php echo "$address?f=$urlimage"; ?>" alt="Thumbnail">
				</td>
			</tr>
	</body>
</html>
