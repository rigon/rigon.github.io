#ifndef _REGMACHINE_INC
#define _REGMACHINE_INC

#include <stdio.h>
#include <stack>

#define a	'a'
#define b	'b'


class Epsilon { };

class Register {
	std::stack<char> s;
public:
	Register();
	Register(const char *init);

	Register& operator=(Register& R);
	Register& operator+(char c);
	Register& operator-(char c);
	Register *operator=(Epsilon& e);

	bool is_empty();
	bool is_char(char c);
	void print();
};


extern Epsilon E;
extern Register *_R_TMP; 
extern int _R_TMP_counter;


#define INIT_REGMACHINE(a) \
	int _compute_REGMACHINE(const char *);\
	int main() {\
		return _compute_REGMACHINE( a );\
	}\
	int _compute_REGMACHINE(const char *_A) {

#define END_REGMACHINE	; }


#define PAUSE	; getchar();
//#define _LABEL(x)	L##x : 
//#define L		; _LABEL(
#define IF		: _R_TMP_counter=0; _R_TMP = 
#define THEN	; if(_R_TMP->is_empty()) goto 
#define ELSE	; else if(_R_TMP->is_char(_A[_R_TMP_counter++])) goto 
#define OR		ELSE
#define LET		: 
#define PRINT	: R0.print()
#define HALT	: return 0
#define GOTO	: goto

#endif /* _REGMACHINE_INC */
