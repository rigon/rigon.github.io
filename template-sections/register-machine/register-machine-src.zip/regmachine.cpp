#include "regmachine.h"

Epsilon E;
Register *_R_TMP;
int _R_TMP_counter;


Register::Register() { }

Register::Register(const char *init) {
	for(int i=0;init[i]!='\0';i++)
		s.push(init[i]);
}

Register& Register::operator=(Register& R) {
	return R;
}

Register& Register::operator+(char c) {
	s.push(c);
	return *this;
}
Register& Register::operator-(char c) {
	if(s.top()==c)
		s.pop();
	return *this;
}

Register *Register::operator=(Epsilon& e) {
	return this;
}

bool Register::is_empty() {
	return s.empty();
}

bool Register::is_char(char c) {
	return s.top()==c;
}

void Register::print() {
	std::stack<char> tmp;
	while(!s.empty()) {
		tmp.push(s.top());
		s.pop();
	}
	while(!tmp.empty()) {
		s.push(tmp.top());
		putchar(tmp.top());
		tmp.pop();
	}
	putchar('\n');
}

