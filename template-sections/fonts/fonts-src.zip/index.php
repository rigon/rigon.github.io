<?php
$fonts_types= array( "truetype" => ".ttf", "opentype" => ".otf" );
if(isset($_GET['f'])) {
	try {
		$url = $_GET['f'];
		$is_test = isset($_GET['test']);
		
		#`wget -O fonts.zip $url > /dev/null`;
		$bin=file_get_contents($url);
		$file=fopen("fonts.zip","wb");
		fwrite($file,$bin);
		fclose($file);
		
		$zip = new ZipArchive();
		if($zip->open("fonts.zip") === true) {
			for($i = 0; $i < $zip->numFiles; $i++) {
				$filename = $zip->getNameIndex($i);
				
				foreach($fonts_types as $needle_k => $needle_v) {
					if($pos = strripos($filename, $needle_v) !== false) {
						if($is_test) {
							$font_name=substr($filename, 0, strripos($filename, $needle_v));
							$font_type=$needle_k;
							break 2;
						}
						else {
							#echo "File Contents:\n";
							$zip_stats = $zip->statIndex($i);
							$zip_fp = $zip->getStream($filename);
							if(!$zip_fp)
								die($zip->getStatusString());
							
							header("Content-Type: font/ttf");
							header("Content-Disposition: attachment; filename=\"$filename\"");
							header("Content-Length: ".$zip_stats['size']);
							header("Access-Control-Allow-Origin: *");
							//header("Cache-Control: max-age=3600, must-revalidate");
							#header("Content-Encoding: gzip");
							#header("Last-Modified: Wed, 26 May 2010 01:28:29 GMT");
							#header("Expires: Wed, 21 Jul 2010 22:16:59 GMT");
							#header("Date: Wed, 21 Jul 2010 22:16:59 GMT");
							#header("X-Content-Type-Options: nosniff");
							#header("X-Frame-Options: SAMEORIGIN");
							#header("X-XSS-Protection: 1; mode=block");
							while (!feof($zip_fp)) {
								echo fread($zip_fp, 1024);
							}
							fclose($zip_fp);

							exit(0);
						}
					}
				}
			}
			$zip->close();
		}
	}
	catch (Exception $e) {
		echo '<h1>Error</h1><br>Caught exception: ',  $e->getMessage(), "\n";
	}
}

$font_name=( isset($font_name) ? $font_name : "EARTH" );
$font_type=( isset($font_type) ? $font_type : "truetype" );
$protocol = ($_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' || $_SERVER['HTTPS'] == 'on') ? 'https' : 'http';
$address=$protocol.'://'.$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'];
$font_url=urlencode(!isset($_GET['f']) ? substr($address, 0, strrpos($address, '/')).'/earth.zip' : $_GET['f'] );


?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" 
   "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html>
	<head>
		<title>Fonts</title>
	
		<style type="text/css">
			@font-face {
				font-family: "<?php echo $font_name; ?>";
				font-style: normal;
				font-weight: normal;
				src: local("<?php echo $font_name; ?>"), url("<?php echo $_SERVER['PHP_SELF']; ?>?f=<?php echo $font_url; ?>") format("<?php echo $font_type; ?>");
			}
			
			/* Example from Google Fonts */
			@font-face {
				font-family: 'Cantarell';
				font-style: normal;
				font-weight: normal;
				src: local('Cantarell'), url('http://themes.googleusercontent.com/font?kit=tGao7ZPoloMxQHxq-2oxNA') format('truetype');
			}

			
			html {
				background-color: #333;
			}
			body {
				background-color: white;
				color: #4b4742;

				line-height: 20px;
				font-family: georgia;
				border: 1px solid black;
				margin: 20px auto 20px auto;
				padding: 20px 50px 20px 50px;
				max-width: 80%;
				min-height: 750px;
				
				-moz-box-shadow: 0px 0px 60px black;
				-webkit-box-shadow: 0px 0px 60px black;
				/* box-shadow: 0px 0px 60px black; */
				
				-webkit-border-radius: 10px;
				-moz-border-radius: 10px;
				text-align: justify;
			}

			a {
				color: #4b4772;
				text-decoration: inherit;
			}

			a:HOVER, a:FOCUS {
				color: #9b97a2;
				text-decoration: overline;
			}
			
			pre {
				font-family: "<?php echo $font_name; ?>";
				font-size: 40px;
				line-height: normal;
				padding: 10px 10px 10px 10px;
				background-color: #f4ffff;
				margin: 20px 0px 20px 0px;
				border: 1px dotted #bcdeff;
				overflow: auto;
			}
			
			code {
				display: block;
				border: 1px dotted #bcdeff;
				padding: 5px 5px 5px 5px;
				background-color: #f4ffff;
				margin: 10px 0px 10px 0px;
				overflow: auto;
				width: 100%;
				white-space: nowrap;
			}
			
			h1 {
				vertical-align: middle;
				font-size: 40px;
				text-shadow: 1px 1px 1px lightgray;
			}
			p {
				margin: 0px 0px 5px 0px;
			}
		</style>
	</head>
	<body>
		<h1>Customized fonts in your site</h1>
		<p>
		This application extract the first font file (True Type Font - TTF or Open Type Font - OFT) in a zip archive.
		It is ideal to get the font file from original source and insert it in your site.
		Example of sites:</p>
		<ul>
			<li><a href="http://www.dafont.com/" target="_blank">dafont.com</a></li>
			<li><a href="http://www.1001freefonts.com/" target="_blank">1001 Free Fonts</a></li>
		</ul>
		<p>To use in your site, you need add some CSS code:
			<code>
				@font-face {<br />
				&nbsp;&nbsp;&nbsp;&nbsp;font-family: "<?php echo $font_name; ?>";<br />
				&nbsp;&nbsp;&nbsp;&nbsp;font-style: normal;<br />
				&nbsp;&nbsp;&nbsp;&nbsp;font-weight: normal;<br />
				&nbsp;&nbsp;&nbsp;&nbsp;src: local("<?php echo $font_name; ?>"), url("<?php echo $address; ?>?f=<?php echo $font_url; ?>") format("<?php echo $font_type; ?>");<br />
				}
			</code>
		</p>
		<p>The address is <i><?php echo $address; ?>?f=</i><b>&lt;address to download font&gt;</b></p>
		<p>After, you can use your new font normally in CSS:
			<code>
				body {
					font-family: "<?php echo $font_name; ?>";
				}
			</code>
		</p>

		<p>Insert the address to download your font and get it:</p>
		<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="get" name="font">
			<p>
				<input name="f" type="text" value="<?php echo urldecode($font_url) ?>" style="width: 400px" />
				<input type="submit" value="Test Font" name="test" />
				<input type="submit" value="Get Font File" name="get" />
				<input type="button" value="Download ZIP file" onclick="javascript: window.location=font.f.value;" />
			</p>
		</form>
		<p>An example in action:</p>
<pre>ABCDEFGHIJKLMNOPQRSTUVWXYZ
abcdefghijklmnopqrstuvwxyz
0123456789
\|!"#$%&amp;/()=?��+*��,;.:-_@���{[]}&lt;&gt;</pre>
	</body>
</html>
