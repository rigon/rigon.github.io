#include <stdio.h>
#include <string.h>
#include <stdlib.h>
int mult=1;
int offset[4];

char *process(char *s,int *v) {
	int i=0;
	int c=0;
	char *p=s;
	char t;
	
	do {
		for(;!(s[i]>='0' && s[i]<='9');i++);
		p=&s[i];
		for(;s[i]>='0' && s[i]<='9';i++);
		t=s[i];
		s[i]='\0';
		v[c]=atoi(p);
		c++;
		//printf("%i [%c]%d |%d|\n",i,t,t,c);
	} while(t==':' || t==',');
	if(t=='\0')
		return NULL;
	return &s[i];
}
void calc(int *t) {
	t[3]=t[3]+mult*offset[3]; 
	if(t[3]<0) { t[2]--; t[3]+=1000; }
	if(t[3]>999) { t[2]++; t[3]-=1000; }
	
	t[2]=t[2]+mult*offset[2];
	if(t[2]<0) { t[1]--; t[2]+=60; }
	if(t[2]>59) { t[1]++; t[2]-=60; }
	
	t[1]=t[1]+mult*offset[1];
	if(t[1]<0) { t[0]--; t[1]+=60; }
	if(t[1]>59) { t[0]++; t[1]-=60; }
	
	t[0]=t[0]+mult*offset[0];
}
void fill(int m, int n) {
	int p=1;
	for(;n>1;n--)
		p*=10;
	
	for(;p>0;m-=(int)(m/p)*p,p/=10)
		putchar(m/p+'0');
}
void print(int *t) {
	fill(t[0],2);
	putchar(':');
	fill(t[1],2);
	putchar(':');
	fill(t[2],2);
	putchar(',');
	fill(t[3],3);
}

int main(int argc, char **argv) {
	char s[1000];
	int n_lines=0;
	int t[4];
	char *p;

	switch(argc) {
	case 2:
		break;
	case 3:
		mult=atoi(argv[2]);
		break;
	default:
		printf("%s offset mult\n",argv[0]);
		return 1;
	}
	process(argv[1],offset);
	
	while(fgets(s,1000,stdin)!=NULL) {
		if(strlen(s)==0)
			n_lines=0;
		if(n_lines==2) {
			p=s;
			p=process(p,t);
			calc(t);
			print(t);
			printf(" --> ");
			p=process(p,t);
			calc(t);
			print(t);
			putchar('\n');
		}
		else
			printf("%s\n",s);
		n_lines++;
	}
	
	return 0;
}
